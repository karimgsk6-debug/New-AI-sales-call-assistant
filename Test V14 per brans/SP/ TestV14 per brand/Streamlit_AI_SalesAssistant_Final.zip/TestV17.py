
import streamlit as st
import os
from PyPDF2 import PdfReader

# --- Paths ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PDF_DIR = os.path.join(BASE_DIR, "assets", "PDFs")
IMG_DIR = os.path.join(BASE_DIR, "assets", "Images")

brand_pdfs = {
    "Shingrix": os.path.join(PDF_DIR, "Shingrix.pdf"),
    "Trelegy": os.path.join(PDF_DIR, "Trelegy.pdf"),
    "Zejula": os.path.join(PDF_DIR, "Zejula.pdf"),
}

brand_images = {
    "Shingrix": os.path.join(IMG_DIR, "Shingrix_visual.png"),
    "Trelegy": os.path.join(IMG_DIR, "Trelegy_visual.png"),
    "Zejula": os.path.join(IMG_DIR, "Zejula_visual.png"),
}

# --- App Layout ---
st.title("💊 AI Sales Call Assistant with PDF & Visuals")

brand = st.selectbox("Select Product", list(brand_pdfs.keys()))

if brand:
    pdf_path = brand_pdfs.get(brand)
    img_path = brand_images.get(brand)

    if os.path.exists(pdf_path):
        st.subheader(f"📄 {brand} Medical Information")
        with open(pdf_path, "rb") as f:
            reader = PdfReader(f)
            text = ""
            for page in reader.pages[:1]:  # only first page preview
                text += page.extract_text() or ""
            st.text_area("PDF Preview (First Page)", text, height=200)
    else:
        st.error(f"⚠️ PDF for {brand} not found in {pdf_path}")

    if os.path.exists(img_path):
        st.subheader(f"🖼️ {brand} Visual Aid")
        st.image(img_path, use_container_width=True)
    else:
        st.warning(f"⚠️ Visual for {brand} not found")
